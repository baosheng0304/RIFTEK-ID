#include "rf080.h"
#include "serial.h"

/* serial port settings */
#define BAUD_RATE   115200
#define BITS        8
#define PARITY      1
#define STOPS       1
#define TIMEOUT     1

/* device commands */
#define CMD_READ_INFO       0x01
#define CMD_WRITE_PARAM     0x03
#define CMD_READ_MEASURE    0x06

/* debug */
//#define DEBUG_INFO  1
//#define BULK_READ   1

static SerialPort sp;

static bool exec(uint8_t cmd, int tx_len, void *tx, int rx_len, void *rx);

#ifdef DEBUG_INFO
#include <stdio.h>
void dump_hex(const char* name, uint8_t* buf, int len)
{
    int i;
    printf ("%s: \"", name, len);
    for (i=0; i<len; i++)
    {
        printf("%02X%s", buf[i], (i<(len-1)) ? ":" : "");
    }
    printf("\" [%d]\n", len);
}
#endif

bool rf080_connect(const char *port_name)
{
    int res;

    if (!port_name)
    {
        return false;
    }

    res = serialOpenByName(&sp, port_name);
    if (!res)
    {
        return false;
    }

    res = serialSetParameters(&sp, BAUD_RATE, BITS, PARITY, STOPS, TIMEOUT);
    if (!res)
    {
        serialClose(&sp);
        return false;
    }

    return true;
}

bool rf080_disconnect()
{
    int res;

    res = serialClose(&sp);

    return (res != 0);
}

bool rf080_laser_on(bool on)
{
    uint8_t blk[2];
    blk[0] = 0;
    blk[1] = on ? 1 : 0;
    return exec(CMD_WRITE_PARAM, 2, blk, 0, NULL);
}

bool rf080_read_info(rf080_info_t *info)
{
    bool res;

    if (!info)
    {
        return false;
    }

    res = exec(CMD_READ_INFO, 0, NULL, sizeof(rf080_info_t), info);

    return res;
}

bool rf080_read_measure(rf080_measure_t *measure)
{
    bool res;

    if (!measure)
    {
        return false;
    }

    res = exec(CMD_READ_MEASURE, 0, NULL, sizeof(rf080_measure_t), measure);

    return res;
}

#ifdef BULK_READ
static int serialRead_(SerialPort *port, int rx_len, void *rx)
{
    int n;
    int left = rx_len;
    int nuls = 0;
    const int max_nuls = 10;
    char *p = (char*)rx;
    do
    {
        n = serialRead(port, left, p);
        if (n > 0)
        {
            p += n;
            left -= n;
            nuls = 0;
        }
        else
            nuls++;
    }
    while (left > 0 && nuls < max_nuls);
    return (rx_len - left);
}
#endif

static bool exec(uint8_t cmd, int tx_len, void *tx, int rx_len, void *rx)
{
    int res;
    uint8_t *data;
    int data_len;
    uint8_t *p;
    int i;

    serialFlushInput(&sp);
    serialFlushOutput(&sp);

    data_len = tx_len * 2 + 2;
    data = (uint8_t*) malloc(data_len);
    data[0] = 1;
    data[1] = 0x80 | cmd;
    if (tx_len > 0)
    {
        p = (uint8_t*)tx;
        for (int i=0; i<tx_len; i++)
        {
            data[i*2 + 2] = 0x80 | (*p & 0x0F);
            data[i*2 + 3] = 0x80 | ((*p >> 4) & 0x0F);
            p++;
        }
    }

#ifdef DEBUG_INFO
        dump_hex("tx", data, data_len);
#endif

    res = serialWrite(&sp, data_len, data);

    free(data);

    if (res < data_len)
    {
        return false;
    }

    if (rx_len > 0)
    {
        data_len = rx_len * 2;
        data = (uint8_t*) malloc(data_len);

#ifndef BULK_READ
        res = serialRead(&sp, data_len, data);
#else
        res = serialRead_(&sp, data_len, data);
#endif

#ifdef DEBUG_INFO
        dump_hex("rx", data, res);
#endif

        if (res < data_len)
        {
            free(data);
            return false;
        }

        p = (uint8_t*)rx;
        for (int i=0; i<rx_len; i++)
        {
            if (i>0 && (((data[i*2] & 0xF0) | (data[i*2 + 1] & 0xF0)) != (data[0] & 0xF0)))
            {
                res = 0;
                break;
            }
            *p = (data[i*2] & 0x0F) | ((data[i*2 + 1] & 0x0F)<<4);
            p++;
        }

        free(data);
    }

    return (res > 0);
}
