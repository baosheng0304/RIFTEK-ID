#ifndef __RF080_H__
#define __RF080_H__

#if (defined _WIN32)
#define RF080_DECL_EXPORT __declspec(dllexport)
#else
#define RF080_DECL_EXPORT
#endif

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#include <stdint.h>
#include <stdbool.h>

#pragma pack(push,1)
typedef struct _rf603_info_t
{
    uint16_t sn;        // serial number
    uint16_t base;      // measuring base
    uint16_t range;     // measuring range
} rf603_info_t;
typedef struct _rf080_info_t
{
    uint8_t id;         // device id (96)
    uint8_t sw;         // software version
    uint16_t sn;        // serial number
    uint16_t type;      // assembly type (27)
    uint16_t flen;      // result file length
    uint16_t fcnt;      // number of records in result file
    rf603_info_t si[6]; // sensors information
    uint8_t reserved[28];
} rf080_info_t;

typedef struct _rf080_measure_t
{
    uint16_t vb;    // battery voltage
    uint16_t ib;    // battery current
    uint16_t v[6];  // laser sensors values
} rf080_measure_t;
#pragma pack(pop)

RF080_DECL_EXPORT bool rf080_connect(const char *port_name);
RF080_DECL_EXPORT bool rf080_disconnect();
RF080_DECL_EXPORT bool rf080_laser_on(bool on);
RF080_DECL_EXPORT bool rf080_read_info(rf080_info_t *info);
RF080_DECL_EXPORT bool rf080_read_measure(rf080_measure_t *measure);

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif //__RF080_H__
